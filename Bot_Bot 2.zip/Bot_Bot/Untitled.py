from bot_bot.bot import FullRealBot
import threading
import time
import random
import sys

def barra_progresso(total):
    print("carregando...")
    for i in range(total + 1):
        porcentagem = (i / total) * 100
        barra = "#" * i + "-" * (total - i)
        sys.stdout.write(f"\r[{barra}] {porcentagem:.0f}%")
        sys.stdout.flush()
        time.sleep(0.2)  # Tempo entre os passos
    print("\nConcluído!")

# --- Bot Minerador em Loop ---
def miner_bot(username):
    bot = MinecraftChatBot(host='guilherminhohh.aternos.me', port=19302, username=username)
    barra_progresso(100)
    bot.connect()
    time.sleep(2)
    try:
        while True:
            bloco = random.choice(['stone', 'coal_ore', 'iron_ore'])  # Minerando tipos diferentes
            bot.mine(bloco)
            print(f"{username} minerou: {bloco}")
            time.sleep(1)
    except Exception as e:
        print(f"{username} finalizou por erro: {e}")
    finally:
        bot.disconnect()

# --- Bot Lutador em Loop ---
def fighter_bot(username):
    bot = MinecraftChatBot(host='guilherminhohh.aternos.me', port=19302, username=username)
    barra_progresso(100)
    bot.connect()
    time.sleep(2)
    try:
        while True:
            bot.attack('nearest')  # Sempre atacando o mob mais próximo
            print(f"{username} atacou uma entidade próxima.")
            time.sleep(1)
    except Exception as e:
        print(f"{username} finalizou por erro: {e}")
    finally:
        bot.disconnect()

# --- Criar e iniciar os bots em threads separadas ---
threads = []

# 3 mineradores
for i in range(3):
    t = threading.Thread(target=miner_bot, args=(f'MinerBot{i+1}',))
    threads.append(t)

# 2 lutadores
for i in range(2):
    t = threading.Thread(target=fighter_bot, args=(f'FighterBot{i+1}',))
    threads.append(t)

# Iniciar todos os bots
for t in threads:
    t.start()

# Esperar todos terminarem (vai rodar infinito até você parar)
for t in threads:
    t.join()