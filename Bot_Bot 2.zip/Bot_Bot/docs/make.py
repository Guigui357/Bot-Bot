"""
Run 'python make.py html' inside this directory to build the documentation.
"""

from make_sphinx_documentation import main

if __name__ == "__main__":
    main()
