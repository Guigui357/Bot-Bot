# Created with Pyto

from bot_bot import main

if __name__ == "__main__":
    main()
